var request = require('request');
var fs = require('fs');
var logger = require("./logger.js");

// not available locally, only on ACCS 
var settings = require("./proxy-settings.js");



var eventBridge = module.exports;
var apiURL = "/eventBridge";
var moduleName = "accs.eventBridge";


var eventhubURL = "https://129.144.152.204:1080/restproxy";
var topicName = "partnercloud17-SoaringEventBus";
var groupName = "workflow-events-consumer-group";
var consumerName = "workflow-events-consumer";


eventBridge.registerListeners =
    function (app) {

        app.get(apiURL + '/about', function (req, res) {
            console.log('event bridge: about');
            eventBridge.handleAbout(req, res);
        });
        app.post(apiURL + '/ifttt-tweet', function (req, res) {
            console.log('EventBridge IFTTT-TWEET POST');
            console.log('body in request' + JSON.stringify(req.body));
            eventBridge.postNewTweet(req, res, req.body);
        });//post messages

        app.post(apiURL + '/messages', function (req, res) {
            console.log('EventBridge POST Messages - now show params');
            console.log('EventBridge POST params ' + JSON.stringify(req.params));
            console.log('body in request' + JSON.stringify(req.body));
            eventBridge.postMessages(req, res, req.body);
        });//post messages

    }//registerListeners

console.log("EventBridge (version " + settings.APP_VERSION + ") initialized at " + apiURL + " running against EventHub Service URL " + eventhubURL);



eventBridge.handleAbout = function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write("EventBridge - About - Version " + settings.APP_VERSION + ". ");
    res.write("Supported URLs:");
    res.write(apiURL + "/ifttt-tweet (POST)");
    res.write(apiURL + "/messages (POST)");
    res.write("incoming headers" + JSON.stringify(req.headers));
    res.end();
}//handleAbout


/* Tweet:
 { "text":"Fake 2 #oraclecode Tweet @StringSection" 
             , "author" : "lucasjellema"
             , "authorImageUrl" : "http://pbs.twimg.com/profile_images/427673149144977408/7JoCiz-5_normal.png"
             , "createdTime" : "April 17, 2017 at 01:39PM"
             , "tweetURL" : "http://twitter.com/SaibotAirport/status/853935915714138112"
             , "firstLinkFromTweet" : "https://t.co/cBZNgqKk0U"
             }
*/

eventBridge.postNewTweet = function (req, res, tweet) {
    var msg = {
        "records": [{
            "key": "NewTweetEvent"
            , "value": {
                "tweet": tweet
                , "module": "soaring.clouds." + moduleName
                , "timestamp": Date.now()

            }
        }]
    };
    eventBridge.postMessages(req,res,msg);
}

eventBridge.postMessages = function (req, res, messages) {
    eventBridge.postMessagesToEventHub(messages, function (response) {
        res.json(response).end();
    })
}// postMessages

eventBridge.postMessagesToEventHub = function (messages, callback) {
    var route_options = {
        /*key: fs.readFileSync('ssl/server1.key'),*/
        cert: fs.readFileSync('./event-hub.pem'),
        requestCert: true,
        rejectUnauthorized: false,
    };

    // Issue the POST  -- the callback will return the response to the user
    route_options.method = "POST";
    route_options.uri = eventhubURL.concat('/topics/').concat(topicName);

    console.log("Target URL " + route_options.uri);
    var args = {
        data: {},
        headers: {
            "Content-Type": "application/vnd.kafka.json.v1+json"
            , "Authorization": "Basic YWRtaW46T29vdzIwMTY="
        }
    };
    args.data = messages;
    route_options.body = JSON.stringify(args.data);
    route_options.headers = args.headers;
    request(route_options, function (error, rawResponse, body) {
        if (error) {
            console.log("Error in call " + JSON.stringify(error));
        } else {
            console.log(rawResponse.statusCode);
            console.log("BODY:" + JSON.stringify(body));
            // Proper response is 204, no content.
            var responseBody = {};
            responseBody['status'] = 'POST  returned '.concat(rawResponse.statusCode.toString());
            if (callback) {
                callback(responseBody);
            }
        }//else
    });//request

}// postMessages



