var logger = require("./logger.js");
var settings = require("./proxy-settings.js");
var cacheAPI = require("./cache-api.js");
var eventhubAPI = require("./eventhub-api.js");

var tweetBoard = module.exports;
var moduleName = "accs.tweetBoard";
var apiURL = "/tweetBoard";

var refreshInterval = 10; //seconds

// the tweet board will check the EventHub every 10 seconds for workflow events of type TweetBoardCapture
// it will add the newest tweets to the tweetboard document in the cache

var TweetBoardCaptureActionType = "TweetBoardCapture";
var workflowEventKey = "WorkflowEvent"; // key for messages regarding workflow events
var tweetBoardDocumentKey = "tweetboard-document";
var eventHubConsumerGroupName = "workflowEventsConsumer";



tweetBoard.registerListeners =
    function (app) {

        app.get(apiURL + '/about', function (req, res) {
            console.log('Tweet-Board: about');
            tweetBoard.handleAbout(req, res);
        });
        app.get(apiURL , function (req, res) {
            console.log('Tweet-Board: about');
            tweetBoard.handleTweetBoard(req, res);
        });
    }//registerListeners


function handleTweetBoard(req, res) {
	cacheAPI.getFromCache(tweetBoardDocumentKey, function (response) {
		res.statusCode = 200;
		res.setHeader('Content-Type', 'application/json');
		res.send(JSON.stringify(response.value));
	});//getFromCache

}//handleLikes


initHeartbeat = function (interval) {
    setInterval(function () {
        checkWorkflowEvents();
    }
        , interval ? interval * 1000 : refreshInterval
    ); // setInterval 3000 is 3 secs
}//initHeartbeat


initHeartbeat(refreshInterval)
console.log("Tweet Board (version " + settings.APP_VERSION + ") initialized with refreshInterval of " + refreshInterval + " seconds.");


function checkWorkflowEvents() {
    // console.log('check likes');
    eventhubAPI.createConsumerGroup(eventHubConsumerGroupName, function (response) {
        //console.log("after create consumer group "+response);
        eventhubAPI.getMessagesFromConsumerGroup(eventHubConsumerGroupName, function (response) {
            //  console.log("Events: ");
            //console.log(response.body);
            var messages = JSON.parse(response.body);
            if (settings.runLocally()) {
                console.log("run locally, so  no cache interaction");
                var tweetBoardDoc;
                tweetBoardDoc = {
                    "offset": 0
                    , "timestamp": Date.now()
                    , "tweets": []
                }
                if (messages) {
                    processTweetBoardActions(tweetBoardDoc, messages);
                }

            } else {  // not locally

                cacheAPI.getFromCache(tweetBoardDocumentKey, function (response) {
                    try {
                        //              console.log("from cache " + JSON.stringify(response));
                        var tweetBoardDoc;
                        if (response.statusCode == '404') {
                            tweetBoardDoc = {
                                "offset": 0
                                , "timestamp": Date.now()
                                , "tweets": []
                            }
                        }
                        else { tweetBoardDoc = response.value };


                        tweetBoardDoc.timestamp = Date.now();
                        if (messages) {

                            // process the results from EventHub into the tweetBoardDoc
                            // get all messages with key workflowEvent and type=TweetBoardCapture 
                            // loop through them and aggregate
                            processTweetBoardActions(tweetBoardDoc, messages);
                        }
                        console.log("TweetBoardDoc REAL: %%%%%%%%%%%%%%%%%%%" + JSON.stringify(tweetBoardDoc));



                        cacheAPI.putInCache(tweetBoardDocumentKey, JSON.stringify(tweetBoardDoc), function (response) {
                            console.log("put tweetBoardDoc in cache " + response);


                        });//putInCache
                    }
                    catch (e) {
                        console.log("Exception in checkWorkflowEvents" + e);
                        console.log("Exception in checkWorkflowEvents" + JSON.stringify(e));
                    }
                });//getFromCache
            }//else
        }); // eventHubAPI get messages
    }); //eventhubAPI create consumer group


}//checkWorkflowEvents

function processTweetBoardActions(tweetBoardDoc, messages) {
    var offset = tweetBoardDoc.offset ? tweetBoardDoc.offset : 0;
    for (index = 0; index < messages.length; ++index) {
        msg = messages[index];
        // only process messages beyond the current offset
        if (msg.offset > offset && msg.key == workflowEventKey) {
            // check if msg has actions
            var event = msg.value;
            if (event.actions) {

                // check if there is an action of type TweetBoardCapture with status = new
                var acted = false;
                for (i = 0; i < event.actions.length; i++) {
                    var action = event.actions[i];
                    // find action of type ValidateTweet
                    if (TweetBoardCaptureActionType == action.type) {
                        // check if any conditions are not yet methodName(params) 
                        if ("new" == action.status) {
                            // if all systems are go, then add the validated, enriched tweet to the tweet board    
                            tweetBoardDoc.tweets.push(event.payload);
                            // update action in event
                            action.status = 'complete';
                            // add audit line    

                            acted = true;
                        }// 
                    }// if TweetBoardCapture
                    // if any action performed, then republish workflow event and store routingslip in cache
                    if (acted) {
                        //todo publish event
                        event.updateTimeStamp = new Date().getTime();
                        event.lastUpdater = moduleName;
                        var msg = {
                            "records": [{
                                "key": workflowEventKey
                                , "value": event
                            }]
                        };
                        eventBridge.postMessages(req, res, msg);
                    }
                }//for
            }//if
        }//for
        // use logic in log-processor to prevent list from growing too long
        //TODO
        // set new offset
        if (messages && messages.length > 0) {
            tweetBoardDoc.offset = messages[messages.length - 1].offset;
        }
    }//for
}//processTweetBoardActions