# node-mediator-proxy
Node.js application that will act as a proxy - accepting HTTP requests and forwarding them to HTTPS targets
