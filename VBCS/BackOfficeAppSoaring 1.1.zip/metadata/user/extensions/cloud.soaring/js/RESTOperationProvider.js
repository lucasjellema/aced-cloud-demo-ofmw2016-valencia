define([
    'bop/js/api/operation/BOPAuthenticators',
    'bop/js/api/operation/OperationBuilder',
    'bop/js/api/resource/Resource',
    'operation/js/api/Operation',
    'operation/js/api/OperationResult'
], function (
    BOPAuthenticators,
    OperationBuilder,
    Resource,
    Operation,
    OperationResult
) {

        'use strict';

        var RESTOperationProvider = function (dependencies) {

            var self = this;
            this._operations = [];
            this._resources = [];
            this._baseUri = "http://private-5c53f5-acedemoactsapi.apiary-mock.com/acedemoactsapi/proposedacts";

            // Check to see if entity is registerd, and if so provide a simple
            // read operation for a list of entities

            var userEntity = Abcs.Entities().findById(RESTOperationProvider.USER_ENTITY_ID);
            if (userEntity) {
                this._operations.push(new OperationBuilder({
                    name: 'Fetch all acts',
                    type: Operation.Type.READ_MANY,
                    performs: function (operationData) {


                        // return self.getAuthenticator().invoke({
                        //     url: self._baseUri,
                        //     method: 'GET',
                        //     dataType: 'json'
                        // });
                        var ajaxObj = {
                            method: 'GET',
                            url: self._baseUri,
                            dataType: 'json'
                        };

                        return new Promise(function (fulfil, reject) {
                            self.getAuthenticator().invoke(ajaxObj).then(function (response) {
                                var arr = RESTOperationProvider._parseDetails(response);
                                return fulfil(OperationResult.success(arr));
                            });
                        });
                    }
                }).description('Fetch all users from the jsonplaceholder users resource')
                    .returns(userEntity)
                    .build());

                RESTOperationProvider._parseDetails = function (response) {
                    console.log('Hello');
                    var res = [];
                    var data = response.getData();
                    console.log('data: ');
                    console.log(data);
                    data.proposedActs.ProposedActSummary.forEach(function (items) {
                        res.push(items);
                    });
                    return res;
                };

                // Generate the resource model required to configure the security model
                //
                this._resources.push(
                    Resource.create({
                        id: '1',
                        template: self._baseUri,
                        entity: RESTOperationProvider.USER_ENTITY_ID
                    })
                );
            }

            // Create an instance of authenticator

            this._authenticator = BOPAuthenticators.getDefault(dependencies, {
                getResources: function () {
                    return self._resources;
                }
            });

        };

        RESTOperationProvider.USER_ENTITY_ID = 'cloud.soaring.user';

        RESTOperationProvider.prototype.getOperations = function () {
            return this._operations;
        };

        RESTOperationProvider.prototype.getAuthenticator = function () {
            return this._authenticator;
        };


        return RESTOperationProvider;
    });
