define([
    'bop/js/api/entity/DataModelFactory',
    'entity/js/api/PropertyType'
], function (
        DataModelFactory,
        PropertyType
        ) {

    'use strict';

    var RESTEntityProvider = function () {};
    
    RESTEntityProvider.USER_ENTITY_ID = 'cloud.soaring.user';
    
    RESTEntityProvider.prototype.getEntities = function() {
        
        var self = this;
        
        // Lazily create entities, this model is not used for RT or most DT.
        // Do the entity creation as late as possible.
        
        if(!self._entities) {
            self._entities = [];
            self._entities.push(DataModelFactory.createEntity({
                id: RESTEntityProvider.USER_ENTITY_ID,
                singularName: 'Act',
                pluralName: 'Acts',
                description: 'A list of Acts',
                properties: [
                    DataModelFactory.createProperty({
                        id: 'id',
                        name: 'ID',
                        type: PropertyType.KEY
                    }),
                    DataModelFactory.createProperty({
                        id: 'name',
                        name: 'Name',
                        type: PropertyType.TEXT
                    }),
                    DataModelFactory.createProperty({
                        id: 'numberOfVotes',
                        name: 'Number of Votes',
                        type: PropertyType.TEXT
                    }),
                    DataModelFactory.createProperty({
                        id: 'registrationDate',
                        name: 'Registration Date ',
                        type: PropertyType.TEXT
                    })
                ]
            }));
        }
        
        return self._entities;
    };

    return RESTEntityProvider;
});