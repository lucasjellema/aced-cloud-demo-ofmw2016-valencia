module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.get('/mobile/custom/artistapi/acts', function(req,res) {
		var result = {};
		res.send(200, result);
	});

	service.get('/mobile/custom/artistapi/acts/:id', function(req,res) {
		var result = {};
		res.send(200, result);
	});

	service.get('/mobile/custom/artistapi/acts/:id/:imageID', function(req,res) {
		var result = {};
		res.send(200, result);
	});

};
